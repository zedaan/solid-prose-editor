## How to run this project
To run this project run the following commands:

To install the dependencies run ``npm install`` or ``yarn``.

Once the dependencies are installed run ``npm start`` or ``yarn start`` to run the project on your local machine.

To build for production run ``npm run build`` 0r ``yarn run build``
